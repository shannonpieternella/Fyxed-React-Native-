import { StyleSheet, Text, View, Image, ImageBackground, TextInput, Button, Touchable, Pressable } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Icon } from 'react-native-elements';
import { color } from 'react-native-elements/dist/helpers';
import { useEffect, useState } from 'react';
import axios from 'axios';
import AsyncStorage from "@react-native-async-storage/async-storage";


export default function Signup() {

  const [voornaam, setVoornaam] = useState('');
  const [achternaam, setAchternaam] = useState('');
  const [telefoon, settelefoon] = useState('');
  const [email, setemail] = useState('');
  
  useEffect(async() => {
    const value = await AsyncStorage.getItem('iduser');
   console.log('Voornaam ' + voornaam)
   console.log('Achternaam ' + achternaam)
   console.log('telefoon ' + telefoon)
   console.log('Email ' + email)
   console.log('iduser ' + value)
   


  }, [voornaam, achternaam, telefoon, email])

  const saveProfile = async () => {
    const pushtokenuser = await AsyncStorage.getItem('pushToken');
    if(pushtokenuser != null){
      const payload = {
        naam: voornaam,
        lastname: achternaam,
        telefoonnr: telefoon,
        emailadres: email,
        pushtoken: pushtokenuser,
        ondernemer: false,
        ondernemerId: "false"
    
      } 

      const userPost = await axios.post('https://fyxedsearch.herokuapp.com/posts/gebruikers', payload)
  // const response = userPost;
  console.log('Response ' + userPost.data._id);
  await AsyncStorage.setItem('iduser', userPost.data._id)
    }else{
      const payload = {
        naam: voornaam,
        lastname: achternaam,
        telefoonnr: telefoon,
        emailadres: email,
        pushtoken: "false",
        ondernemer: false,
        ondernemerId: "false"
    
      } 

      const userPost = await axios.post('https://fyxedsearch.herokuapp.com/posts/gebruikers', payload)
  // const response = userPost;
  console.log('Response ' + userPost.data._id);
  await AsyncStorage.setItem('iduser', userPost.data._id)

    
    } 

  


  }


    return (
      <View style={styles.container}>
        
<View style={styles.bgview}>
       
        <View style={styles.header}>
          
        {/* <Image source={require('../assets/arrow.png')} style={styles.arrowicon} /> */}
        <Image source={require('../assets/fyxedlogo.png')} style={styles.logoheader} />
</View >

<View style={styles.hiview}>
<Text style={styles.textlogin}>
Profiel
</Text>
{/* <Image source={require('../assets/fyxedicon.png')} resizeMode="contain" style={styles.iconhi} /> */}

</View>
<View style={styles.loginContainerParent2}>

<Pressable style={{ height: 60, width: 325, alignSelf: 'center', paddingLeft: 15, flexDirection: 'row', alignItems: 'center' }}
>

  <Text style= {{fontSize: 16, paddingRight: 50, color: '#FFBF00'}}>Het ziet er naar uit dat je geen profiel hebt. <Text style={ {color: 'white'}}>Creer hier je profiel.</Text></Text>
</Pressable>  

<TextInput
      style={{ height: 45, borderWidth: 1, backgroundColor: '#ffffff', width: 300, borderRadius: 20, alignSelf: 'center', paddingLeft: 8}}
      onChangeText={text => setVoornaam(text)}
      // value={value}
      color="black"
      placeholder="Voornaam"
      placeholderTextColor="black" 
    />

<TextInput
      style={{ height: 45, borderWidth: 1, backgroundColor: '#ffffff', width: 300, borderRadius: 20, alignSelf: 'center', paddingLeft: 8}}
      onChangeText={text => setAchternaam(text)}
      // value={value}
      color="black"
      placeholder="Achternaam"
      placeholderTextColor="black" 
    />

<TextInput
      style={{ height: 45, borderWidth: 1, backgroundColor: '#ffffff', width: 300, borderRadius: 20, alignSelf: 'center', paddingLeft: 8}}
      onChangeText={text => settelefoon(text)}
      // value={value}
      color="black"
      placeholder="Telefoonnummer"
      placeholderTextColor="black" 
    />

<TextInput
      style={{ height: 45, borderWidth: 1, backgroundColor: '#ffffff', width: 300, borderRadius: 20, alignSelf: 'center', paddingLeft: 8}}
      onChangeText={text => setemail(text)}
      // value={value}
      color="black"
      placeholder="Email"
      placeholderTextColor="black" 
    />

<Pressable onPress={()=> saveProfile()} style={{ height: 45, borderWidth: 1, backgroundColor: '#FFBF00', width: 300, borderRadius: 20, alignSelf: 'center', paddingLeft: 35, justifyContent: 'space-between', flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}
>

  <Text style= {{fontSize: 16, paddingRight: 50, color: 'white'}}>Opslaan</Text>
</Pressable>

<Pressable style={{ height: 45, width: 325, alignSelf: 'center', paddingLeft: 15, flexDirection: 'row', alignItems: 'center' }}
>

  <Text style= {{fontSize: 12, paddingRight: 50, color: 'white'}}>By selecting Agree and continue below, i agree to <Text style={ {color: '#FFBF00'}}>Terms of Service and Privacy Policy</Text></Text>
</Pressable>  
  




</View>


</View>

        <StatusBar style="auto" />
        
      </View>
    );
  }

  
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
   

  },

  iconlogin: {
height: 30,
width: 30,
justifyContent: 'space-around',
flexDirection: 'row'

  },

   
      
  
  loginContainerParent2: {

  flexDirection: 'column',

  borderRadius: 20,
      // borderWidth: 1,
      borderColor: '#ffffff',
      backgroundColor: '#FFFFFFAD',
     
      height: 450,
      justifyContent:'space-around',
    
      width: 335,
      alignSelf: 'center',
      // justifyContent: 'space-evenly'
      
  

  
  },


  loginContainer: {
height: 350,
width: 300,
// borderRadius: 14,
//     borderWidth: 1,
//     borderColor: '#ffffff',
    // backgroundColor: '#ffffff',
    
  



  },

  hiview: {
   
    height: 75,
    // borderRadius: 14,
    // borderWidth: 1,
    // borderColor: '#ffffff',
    flexDirection: 'row',
    alignItems:'center',
    width: 40
    
  

  },

  background: {
height: 600,



  },

  bgview: {
height: 600,
// width: 400,
marginBottom: 500,


  },

  arrowicon: {
  height: 25,
  width: 25

  },

  header: {
    // borderRadius: 14,
    // borderWidth: 1,
    // // borderColor: '#ffffff',
    height: 80, 
    
    justifyContent: 'center',
    // paddingLeft: 15,
    width: 225,
    // justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center'

  },

  textlogin: {
  color: '#ffffff',
  fontSize: 40,
  marginLeft: 25,
  fontWeight: 'bold',
 paddingLeft: 25,
  width:150

  },

  logoheader: {
height: 35,
width: 200


  },

  iconhi: {
    height: 40,
    width: 40,
    marginTop: 55,
   

    
    
      }
    

});
