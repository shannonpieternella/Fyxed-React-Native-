import StarRating from 'react-native-star-rating';
 
export default function Profielpagina() {
 
    return (
      <StarRating
       
      />
    );
  
}