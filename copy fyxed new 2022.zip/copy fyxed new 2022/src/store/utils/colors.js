export const colors = {
    lighgray: '#f0f0f0',
    gray: '#d3d3d3',
    primary: '#00aaff',
    white: '#fff',
    black: '#000',
    appColor: '#5a45ff',
    nftBtnColor: '#32cc33',
    logoutBtnColor: '#ff0000',
}